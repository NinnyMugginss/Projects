const mongoose = require("mongoose")

const BookSchema = mongoose.Schema({
    id: {
        require:true,
        type: String
    },
    title: String,
    author: String,
    publisher: String,
    isbn: String,
    avail: Boolean,
    who: String,
    due: String
})

const Book = mongoose.model('Book', BookSchema)

module.exports = Book